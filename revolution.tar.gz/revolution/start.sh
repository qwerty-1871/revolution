clear
echo "Welcome to Revolution!"
echo "During this game you will have to navigate life as a peasant before the French Revolution"
echo "You own a small farm as part of a larger noble's estate and as part of the third estate you have very few political and economic rights of your own"
echo "You will have 3 actions each day which you must spend on different actions to keep yourself, your wife, and your three children alive and well"
echo "You will also be presented with different disasters and opprotunities throughout that will further complicate your life"
echo "Please note that events in this game are not completely accurate to history and will occur in much quicker succession than they did in reality"
echo "Good luck!"
read -p "Press ENTER to continue"
exec ./day.sh
exit
