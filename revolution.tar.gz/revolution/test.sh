#!/bin/bash
echo $actions