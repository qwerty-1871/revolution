#!/bin/bash
jacobin=0
prompt=1
run=1
day=1
cash=50
mafu=0 #pests on the farm 0-3
simon=0 #rabies 0-1(hidden)
grow=4 # progress of crops 0 is unplanted 5 is done
cropsgrew=0 # if crops finished growing last night
hascrops=0 # if you have unsold crops, 1 is a full yield 3-5 are quarters 1-3
lsales=0
food=5
hasalf=0
#alive
you=1
wife=1
child1=1
child2=1
child3=1
haswife=1
haschild1=1
haschild2=1
haschild3=1
#how hungry?!!!?!? 0-3 3 is starved to death(very hungry!!)
youhunger=1
wifehunger=1
child1hunger=1
child2hunger=1
child3hunger=1
actions=3
fam=5
growleft=1
foodprice=10
yield=400